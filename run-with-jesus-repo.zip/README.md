# Run with Jesus (예수님과 함께 뛰어요)

Run locally:
```bash
npm install
npm run dev
```

Included:
- Global font color **#CC5500** (affects EN + 한글).
- Background image replaced with `public/background.png` (tiled from your latest file).
- No overlay.
- Username-only login, Join Club, Reset Password.
- Upload Run Moments (client-side resize), view full-size + download.
- Home shows all images sorted by caption; Run 60% / Read 40%.
